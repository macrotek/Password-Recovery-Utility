﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Security.Cryptography;
using System.IO;
namespace PasswordRecovery
{
    public partial class ShowPassword : Form
    {
        public ShowPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Browse Files",

                CheckFileExists = true,
                CheckPathExists = true,

                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName;
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(textBox1.Text);
                doc.Save(Console.Out);

                foreach (XmlNode node in doc.DocumentElement)
                {
                    if (node.Name == "HWInfo")
                    {
                        foreach (XmlNode child in node)
                        {
                            if (child.Name == "Pwd")
                            {
                                string word_translation = node["Pwd"].InnerText;
                                string password = Decrypt(word_translation);
                                
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        public string Decrypt(string word_translatio)
        {
            string passPhrase = "Pas5pr@se";            // can be any string
            string saltValue = "s@1tValue";             // can be any string
            string hashAlgorithm = "SHA1";              // can be "MD5"
            int passwordIterations = 2;                 // can be any number
            string initVector = "Renu Electronics";     // must be 16 bytes
            int keySize = 256;                          // can be 192 or 128
            string decrypData = "";
            string decrypted = "";
            string encrypted = "";
            string plainText = "";
            try
            {
                string cipherText = word_translatio;
                byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
                byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
                byte[] cipherTextBytes = Convert.FromBase64String(cipherText);

                PasswordDeriveBytes password = new PasswordDeriveBytes( passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);

                byte[] keyBytes = password.GetBytes(keySize / 8);

                RijndaelManaged symmetricKey = new RijndaelManaged();

                symmetricKey.Mode = CipherMode.CBC;

                ICryptoTransform decryptor = symmetricKey.CreateDecryptor( keyBytes, initVectorBytes);

                MemoryStream memoryStream = new MemoryStream(cipherTextBytes);

                CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor,  CryptoStreamMode.Read);

                byte[] plainTextBytes = new byte[cipherTextBytes.Length];

                int decryptedByteCount = cryptoStream.Read(plainTextBytes,  0, plainTextBytes.Length);

                memoryStream.Close();
                cryptoStream.Close();

                plainText = Encoding.UTF8.GetString(plainTextBytes,  0,  decryptedByteCount);
                textBox2.Text = plainText;
            }
            catch (Exception e)
            {
                // MessageBox.Show("Configuration file has been changed.Please enter correct password to restore this file.");
            }
            return plainText;
        }

    }
}
